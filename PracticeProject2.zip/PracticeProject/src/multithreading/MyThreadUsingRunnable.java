package multithreading;

public class MyThreadUsingRunnable implements Runnable {

	@Override
	public void run() {
		System.out.println("this thread is created using runnable interface");

	}

}
