package multithreading;

public class MyThreadUsingThread extends Thread {

	@Override
	public void run() {
		System.out.println("this thread is created extending Thread class.");
	}
}
