package assistedPractice;

public class ImplimentationOfArrays {

	public static void main(String[] args) {
		System.out.println("Using For loop");
		int [] a= {10,34,65,37};
		for(int i=0;i<a.length; i++) {
			System.out.println(a[i]);
		int[][] arr = { { 1, 2 }, { 5, 6 } };
        for (int i1 = 0; i < 2; i++)
        for (int j = 0; j < 2; j++)
        	System.out.println("arr[" + i + "][" + j + "] = "+ arr[i][j]);
			
		}

	}

}
