package objectOrientedPillars;

public interface Calculator {
	
	public int sum(int a,int b);
	
	public int difference(int a,int b);
	
	public int product(int a,int b);
	
	public int divison(int a,int b);
	
	

}
 