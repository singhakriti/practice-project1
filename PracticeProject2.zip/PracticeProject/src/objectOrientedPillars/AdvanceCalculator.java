package objectOrientedPillars;

public class AdvanceCalculator extends SimpleCalculator{
	
	public int sum(int a, int b, int c) {
		return a+b+c;
	}
	
}
